function dibujarCara() {
    var cara = `
    _________ 
    |0        0|\r
    |     v     |\r
    | ------- |\r
    |________|\r
        `;
    
        alert(cara);
}

window.onload = function() {
    dibujarCara();
}

//Lo he intentado pero no he sido capaz de hacerla mas bonita
//Lo he intentado con \t pero las tabulaciones las mete con una flechita (singo de la tabulación en el teclado)